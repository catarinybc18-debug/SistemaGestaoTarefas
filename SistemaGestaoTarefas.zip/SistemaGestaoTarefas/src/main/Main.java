package main;
import ui.TelaPrincipal;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TelaPrincipal tela = new TelaPrincipal();
        tela.setVisible(true);
	}

}
