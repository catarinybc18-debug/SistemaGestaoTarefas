package ui;
import model.GerenciadorTarefas;
import model.Tarefa;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
public class TelaPrincipal extends JFrame{
    private GerenciadorTarefas gerenciadorTarefas;
    private DefaultTableModel modeloTabela;
    private JTable tabelaTarefas;

    public TelaPrincipal() {
        gerenciadorTarefas = new GerenciadorTarefas();

        setTitle("Gestão de Tarefas");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Painel para adicionar nova tarefa
        JPanel painelEntrada = new JPanel();
        painelEntrada.setLayout(new FlowLayout());
        JTextField campoDescricao = new JTextField(20);
        JButton botaoAdicionar = new JButton("Adicionar");

        painelEntrada.add(campoDescricao);
        painelEntrada.add(botaoAdicionar);

        // Modelo para a tabela (duas colunas: Descrição e Status)
        modeloTabela = new DefaultTableModel();
        modeloTabela.addColumn("Descrição");
        modeloTabela.addColumn("Status");

        // Tabela que exibe as tarefas
        tabelaTarefas = new JTable(modeloTabela);
        JScrollPane scrollPane = new JScrollPane(tabelaTarefas);

        // Botões de ações
        JButton botaoConcluir = new JButton("Concluir Tarefa");
        JButton botaoRemover = new JButton("Remover Tarefa");

        // Ações dos botões
        botaoAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String descricao = campoDescricao.getText();
                if (!descricao.trim().isEmpty()) {
                    gerenciadorTarefas.adicionarTarefa(descricao);
                    atualizarTabela();
                    campoDescricao.setText("");
                }
            }
        });

        botaoConcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int indiceSelecionado = tabelaTarefas.getSelectedRow();
                if (indiceSelecionado != -1) {
                    gerenciadorTarefas.concluirTarefa(indiceSelecionado);
                    atualizarTabela();
                }
            }
        });

        botaoRemover.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int indiceSelecionado = tabelaTarefas.getSelectedRow();
                if (indiceSelecionado != -1) {
                    gerenciadorTarefas.removerTarefa(indiceSelecionado);
                    atualizarTabela();
                }
            }
        });

        // Layout
        JPanel painelBotoes = new JPanel();
        painelBotoes.add(botaoConcluir);
        painelBotoes.add(botaoRemover);

        // Adiciona os componentes à janela
        add(painelEntrada, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(painelBotoes, BorderLayout.SOUTH);

        atualizarTabela();
    }

    private void atualizarTabela() {
        List<Tarefa> tarefas = gerenciadorTarefas.listarTarefas();
        modeloTabela.setRowCount(0); // Limpa a tabela antes de atualizar
        for (Tarefa tarefa : tarefas) {
            modeloTabela.addRow(new Object[]{tarefa.getDescricao(), tarefa.isConcluida() ? "Concluída" : "Pendente"});
        }

    }
}
	

